% C = resize(A,k,n,m)
% resizes the n*m image A with border k in 1D vector shape
% into a 2D image C with size n*m and no border
% $Id: resize.m,v 1.2 2006/03/08 22:06:58 duin Exp $
