% C = bord(A,n,m)
% Puts a border of width m (default m=1) around image A
% and gives it value n. If n = NaN: mirror image values.
% $Id: bord.m,v 1.3 2007/05/08 15:06:06 duin Exp $
