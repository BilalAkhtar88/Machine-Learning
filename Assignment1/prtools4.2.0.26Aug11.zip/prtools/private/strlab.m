%STRLAB Make sure labels are strings
%
%	LAB_OUT = STRLAB(LAB_IN)
%
% The label list LAB_IN (cells numbers or strings) is converted to a
% string matrix LAB_OUT
