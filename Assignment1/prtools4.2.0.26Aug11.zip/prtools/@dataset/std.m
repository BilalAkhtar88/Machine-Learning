%STD Dataset overload
%
%   [S,U] = STD(A,FLAG,DIM)
%
% Computes std. dev. S and mean U in a single run for consistency with datafile overload.
