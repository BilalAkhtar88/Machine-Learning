%RGB2HSV Dataset overload
%
%  B = RGB2HSV(A)
