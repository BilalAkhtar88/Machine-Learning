%SETNAME Set the name of a dataset
%
%   A = SETNAME(A,NAME)
%
% The NAME of a dataset A is a string that may be used for identifying 
% the dataset and for annotating plots and other outputs.
