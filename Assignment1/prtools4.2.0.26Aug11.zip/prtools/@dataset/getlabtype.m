%GETLABTYPE Get label type of dataset
%
%    LABTYPE = GETLABTYPE(A)
%
% Returns the label type of dataset A.
