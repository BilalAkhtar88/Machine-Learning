%CTRANSPOSE Dataset overload 
%
% Just returns the complex conjugate transpose of the data matrix.
