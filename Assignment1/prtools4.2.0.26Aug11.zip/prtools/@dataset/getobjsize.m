%GETOBJSIZE Get object size
%
%    OBJSIZE = GETOBJSIZE(A,N)
%    [OBJSIZE1,OBJSIZE2,OBJSIZE3] = GETOBJSIZE(A)
%
% Note that the object size can be a scalar, or, in case of feature images,
% an image size vector.
