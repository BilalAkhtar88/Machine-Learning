%EQ Dataset overload
